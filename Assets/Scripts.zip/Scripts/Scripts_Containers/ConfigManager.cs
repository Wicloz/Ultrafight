﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;

public class ConfigManager : MonoBehaviour
{
	public static ConfigManager acces;
	public ConfigFile temp;

	// Folders
	private string folderRoot;
	private string folderCharacters;
	private string folderWeapons;
	private string folderArmour;
	private string folderVehicles;

	// Development GUI
	public GameObject cardTab;

	private string field = "test";
	public int top = 100;
	public int left = 100;

	// Temporary loading data
	private string lastError = "";
	private Queue<string> loadQueue = new Queue<string>();

	// List and info
	public bool allConfigsLoaded = false;

	public int totalConfigs = 0;
	public int loadSucces = 0;
	public int loadFail = 0;

	private List<CardContent> characterList = new List<CardContent>();
	private List<CardContent> equipmentList = new List<CardContent>();

	public List<CardContent> gameCharacterList = new List<CardContent>();
	public List<CardContent> gameEquipmentList = new List<CardContent>();

	void Awake ()
	{
		acces = this;

		folderRoot = Application.dataPath + "\\..\\GameData";
		folderCharacters = folderRoot + "\\Characters";
		folderWeapons = folderRoot + "\\Weapons";
		folderArmour = folderRoot + "\\Armour";
		folderVehicles = folderRoot + "\\Vehicles";
	}

	void Start ()
	{
		Directory.CreateDirectory (folderCharacters);
		Directory.CreateDirectory (folderWeapons);
		Directory.CreateDirectory (folderArmour);
		Directory.CreateDirectory (folderVehicles);

		StartCoroutine("LoadAllConfigs");
	}

	private void CopyCardLists ()
	{
		gameCharacterList = GetCharacterList ();
		gameEquipmentList = GetEquipmentList ();
	}

	public List<CardContent> GetCharacterList ()
	{
		return SerializerHelper.DeserializeFromString<List<CardContent>> (SerializerHelper.SerializeToString (characterList));
	}

	public List<CardContent> GetEquipmentList ()
	{
		return SerializerHelper.DeserializeFromString<List<CardContent>> (SerializerHelper.SerializeToString (equipmentList));
	}

	public void AddClientCharacterCard (CardContent card)
	{
		AddClientCard (card, gameCharacterList);
	}

	public void AddClientEquipmentCard (CardContent card)
	{
		AddClientCard (card, gameEquipmentList);
	}

	public void AddClientCard (CardContent card, List<CardContent> list)
	{
		bool exists = false;

		foreach (CardContent cc in list)
		{
			if (cc.name.ToLower() == card.name.ToLower() && cc.type == card.type)
			{
				exists = true;
			}
		}

		if (!exists)
		{
			Debug.Log ("Adding card " + card.name);
			list.Add (card);
		}
	}

	public List<CardContent> GetCharacterCards (int amount)
	{
		return GetCards (amount, "character");
	}

	public List<CardContent> GetEquipmentCards (int amount)
	{
		return GetCards (amount, "equipment");
	}

	private List<CardContent> GetCards (int amount, string type)
	{
		List<CardContent> sourcelist = new List<CardContent>();

		switch (type)
		{
		case "character":
			sourcelist = gameCharacterList;
			break;
		case "equipment":
			foreach (CardContent card in gameEquipmentList)
			{
				if (card.type != (int)CardType.Vehicle)
				{
					sourcelist.Add (card);
				}
			}
			break;
		}

		List<int> picks = new List<int> ();
		List<CardContent> cards = new List<CardContent> ();
		
		for (int i = 0; i < amount; i++)
		{
			picks.Add (Random.Range (0, sourcelist.Count - 1));
		}
		
		foreach (int i in picks)
		{
			cards.Add (sourcelist[i]);
		}
		
		return cards;
	}

	void OnGUI ()
	{
		if (cardTab.activeSelf)
		{
			field = GUI.TextField(new Rect(left, top, 200, 22), field);

			if (GUI.Button(new Rect(left, top + 40, 200, 40), "Reload Configurations"))
			{
				StartCoroutine("LoadAllConfigs");
			}

			if (GUI.Button(new Rect(left, top + 40 + 50, 200, 40), "Create Character"))
			{
				CreateConfig (folderCharacters + "\\" + field.ToLower() + ".cfg", "character", field);
			}

			if (GUI.Button(new Rect(left, top + 40 + 100, 200, 40), "Create Weapon"))
			{
				CreateConfig (folderWeapons + "\\" + field.ToLower() + ".cfg", "weapon", field);
			}

			if (GUI.Button(new Rect(left, top + 40 + 150, 200, 40), "Create Armour"))
			{
				CreateConfig (folderArmour + "\\" + field.ToLower() + ".cfg", "armour", field);
			}

			if (GUI.Button(new Rect(left, top + 40 + 200, 200, 40), "Create Vehicle"))
			{
				CreateConfig (folderVehicles + "\\" + field.ToLower() + ".cfg", "vehicle", field);
			}

			if (GUI.Button(new Rect(left, top + 40 + 250, 200, 40), "Create a bunch of configs"))
			{
				for (int i = 0; i < 100; i++)
				{
					string name = Random.Range(0, 10000).ToString();

					CreateConfig (folderCharacters + "\\" + name.ToLower() + ".cfg", "character", name);
					CreateConfig (folderWeapons + "\\" + name.ToLower() + ".cfg", "weapon", name);
					CreateConfig (folderArmour + "\\" + name.ToLower() + ".cfg", "armour", name);
					CreateConfig (folderVehicles + "\\" + name.ToLower() + ".cfg", "vehicle", name);
				}
			}
		}
	}

	private IEnumerator LoadAllConfigs ()
	{
		allConfigsLoaded = false;
		characterList = new List<CardContent> ();
		equipmentList = new List<CardContent> ();
		loadSucces = 0;
		loadFail = 0;
	
		foreach (string file in Directory.GetFiles(folderRoot, "*.cfg", SearchOption.AllDirectories))
		{
			loadQueue.Enqueue(file);
		}

		totalConfigs = loadQueue.Count;

		for (int i = 0; i < totalConfigs; i++)
		{
			int thisCount = loadSucces + loadFail;

			Thread load = new Thread(LoadConfigThreaded);
			load.Start();
			yield return null;

			while (thisCount == loadSucces + loadFail)
			{
				yield return null;
			}
		}

		while (totalConfigs != loadSucces + loadFail)
		{
			yield return new WaitForSeconds (1);
		}

		CopyCardLists ();
		allConfigsLoaded = true;
	}

	private void LoadConfigThreaded ()
	{
		string message = LoadConfig(loadQueue.Dequeue());
		Debug.LogError(message);

		lastError = "";

		if (message == "Loading Succesful")
		{
			loadSucces ++;
		}
		else
		{
			loadFail ++;
		}
	}

	private string LoadConfig (string path)
	{
		CardContent card = new CardContent ();
		string mode = "none";

		string file = File.ReadAllText (path);
		ConfigFile cf = ParseBlocks (file);

		temp = cf;

		if (!cf.succes)
		{
			return "Invalid config structure";
		}

		Debug.Log("Starting loading procedure");

		// Create main information
		switch (LoadString(cf.main.content, "type"))
		{
		case "character":
			mode = "character";
			card.type = (int)CardType.Character;
			break;
		case "weapon":
			mode = "equipment";
			card.type = (int)CardType.Weapon;
			break;
		case "armour":
			mode = "equipment";
			card.type = (int)CardType.Armour;
			break;
		case "vehicle":
			mode = "equipment";
			card.type = (int)CardType.Vehicle;
			break;
		default:
			return "Incorrect value for TYPE";
		}
		
		card.name = LoadString (cf.main.content, "name");
		card.usage = LoadString (cf.main.content, "usageVerb");
		card.description = LoadString (cf.main.content, "description");
		card.strength = LoadFromEnum (ConfigContainers.strength, cf.main.content, "strength");
		card.prioritiseRanged = LoadBool (cf.main.content, "prioritiseRangedAttack");
		
		if (LoadBool(cf.main.content, "deployment.submerged"))
		{
			card.deployment.Add((int)Deployment.Submerged);
		}
		if (LoadBool(cf.main.content, "deployment.water"))
		{
			card.deployment.Add((int)Deployment.Water);
		}
		if (LoadBool(cf.main.content, "deployment.land"))
		{
			card.deployment.Add((int)Deployment.Land);
		}
		if (LoadBool(cf.main.content, "deployment.air"))
		{
			card.deployment.Add((int)Deployment.Air);
		}
		
		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			if (LoadBool(cf.main.content, "immunity." + damage.codeName))
			{
				card.immunities.Add (damage.codeName);
			}
		}

		// Create module information
		foreach (ModuleInfo module in cf.modules)
		{
			if (module.type == "melee")
			{
				card.melee.meleeEnabled = LoadBool (module.content, "enabled");
				card.melee.name = LoadString (module.content, "name");

				card.melee.fixedStrength = LoadBool (module.content, "fixedStrength");
				card.melee.strengthModifier = LoadInt (module.content, "strengthModifier");

				card.melee.damageDirectEnabled = LoadBool (module.content, "enableDirectDamage");
				card.melee.damageSmallEnabled = LoadBool (module.content, "enableSmallblastDamage");
				card.melee.damageLargeEnabled = LoadBool (module.content, "enableLargeblastDamage");

				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "directDamage." + damage.codeName))
					{
						card.melee.damageTypesDirect.Add (damage.codeName);
					}
				}
				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "smallDamage." + damage.codeName))
					{
						card.melee.damageTypesSmall.Add (damage.codeName);
					}
				}
				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "largeDamage." + damage.codeName))
					{
						card.melee.damageTypesLarge.Add (damage.codeName);
					}
				}
			}

			else if (module.type == "ranged")
			{
				card.ranged.rangedEnabled = LoadBool (module.content, "enabled");
				card.ranged.name = LoadString (module.content, "name");

				card.ranged.fixedStrength = LoadBool (module.content, "fixedStrength");
				card.ranged.strengthModifier = LoadInt (module.content, "strengthModifier");

				card.ranged.speed = LoadFromEnum (ConfigContainers.projectileSpeed, module.content, "projectileSpeed");
				card.ranged.projectileAmount = LoadInt (module.content, "projectileAmount");

				if (LoadBool(module.content, "targetable.submerged"))
				{
					card.ranged.targetable.Add((int)Deployment.Submerged);
				}
				if (LoadBool(module.content, "targetable.water"))
				{
					card.ranged.targetable.Add((int)Deployment.Water);
				}
				if (LoadBool(module.content, "targetable.land"))
				{
					card.ranged.targetable.Add((int)Deployment.Land);
				}
				if (LoadBool(module.content, "targetable.air"))
				{
					card.ranged.targetable.Add((int)Deployment.Air);
				}

				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "immunity." + damage.codeName))
					{
						card.ranged.projectileImmunities.Add (damage.codeName);
					}
				}
				
				card.ranged.damageDirectEnabled = LoadBool (module.content, "enableDirectDamage");
				card.ranged.damageSmallEnabled = LoadBool (module.content, "enableSmallblastDamage");
				card.ranged.damageLargeEnabled = LoadBool (module.content, "enableLargeblastDamage");

				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "directDamage." + damage.codeName))
					{
						card.ranged.damageTypesDirect.Add (damage.codeName);
					}
				}
				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "smallDamage." + damage.codeName))
					{
						card.ranged.damageTypesSmall.Add (damage.codeName);
					}
				}
				foreach (DamageType damage in DamageTypes.damageTypes)
				{
					if (LoadBool(module.content, "largeDamage." + damage.codeName))
					{
						card.ranged.damageTypesLarge.Add (damage.codeName);
					}
				}
			}

			else
			{
				Debug.Log("Unrecognised module type, skipping load ...");
			}
		}

		// Check and return
		if (lastError != "")
		{
			return lastError;
		}

		switch (mode)
		{
		case "character":
			characterList.Add(card);
			break;
		case "equipment":
			equipmentList.Add(card);
			break;
		}

		if (true && card.name != "template")
		{
			ReWriteConfigFile (cf, path);
		}

		return "Loading Succesful";
	}

	private int LoadFromEnum (Dictionary<string, int> table, List<ConfigField> content, string identifier)
	{
		string key = LoadString (content, identifier);

		if (key == "")
		{
			return 0;
		}

		if (table.ContainsKey(key))
		{
			return table[key];
		}
		else if (lastError == "")
		{
			lastError = "Incorrect value for " + identifier.ToUpper() + " on " + LoadString (content, "name");
		}

		return 0;
	}

	private string LoadString (List<ConfigField> content, string identifier)
	{
		return GetValue (content, identifier);
	}

	private int LoadInt (List<ConfigField> content, string identifier)
	{
		if (GetValue (content, identifier) != "")
		{
			try
			{
				int value = System.Convert.ToInt32 (GetValue (content, identifier));
				return value;
			}
			catch
			{
				if (lastError == "")
				{
					lastError = "Incorrect value for " + identifier.ToUpper() + " on " + LoadString (content, "name");
				}
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}

	private bool LoadBool (List<ConfigField> content, string identifier)
	{
		if (GetValue (content, identifier) != "")
		{
			switch (GetValue (content, identifier))
			{
			case "true":
				return true;
			case "false":
				return false;
			default:
				if (lastError == "")
				{
					lastError = "Incorrect value for " + identifier.ToUpper() + " on " + LoadString (content, "name");
				}
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	private bool ToBool (string input)
	{
		switch (input)
		{
		case "true":
			return true;
		case "false":
			return false;
		default:
			return false;
		}
	}

	private string GetValue (List<ConfigField> fields, string key)
	{
		string s = "";

		foreach (ConfigField field in fields)
		{
			if (field.key == key)
			{
				s = field.value;
			}
		}

		return s;
	}

	private ConfigFile ParseBlocks (string content)
	{
		StringReader sr = new StringReader (content);
		ConfigFile cf = new ConfigFile ();
		
		string currentline = "";
		int moduleNumber = -1;
		string identifierCurrent = "none";
		string identifierNext = "";
		
		bool done = false;

		while (!done)
		{
			currentline = sr.ReadLine();
			Debug.Log("Reading Config Line");

			if (!currentline.Trim().StartsWith("//"))
			{
				if (currentline.Contains("CARD"))
				{
					if (identifierCurrent == "none")
					{
						identifierNext = "card";
					}
					else
					{
						cf.succes = false;
						return cf;
					}
				} // end card
					
				else if (currentline.Contains("MODULE"))
				{
					if (identifierCurrent == "card")
					{
						identifierNext = currentline.Trim().ToLower();
						moduleNumber++;
					}
					else
					{
						cf.succes = false;
						return cf;
					}
				} // end module

				else if (currentline.Contains("{"))
				{
					if (identifierNext != "")
					{
						identifierCurrent = identifierNext;
						identifierNext = "";
					}
					else
					{
						cf.succes = false;
						return cf;
					}
				} // end {
				
				else if (currentline.Contains("}"))
				{
					if (identifierCurrent == "card" && identifierNext == "")
					{
						done = true;
					}
					else if (identifierCurrent.Contains("module") && identifierNext == "")
					{
						identifierCurrent = "card";
					}
					else
					{
						cf.succes = false;
						return cf;
					}
				} // end }

				if (currentline.Contains("=") && currentline.Replace(" ", "").Replace("\t", "").Replace("}", "").Replace("{", "") != "")
				{
					if (identifierCurrent == "card")
					{
						cf.main.content.Add (LineToField (currentline));
					}
					
					else if (identifierCurrent == "module_melee")
					{
						if (cf.modules.Count <= moduleNumber)
						{
							cf.modules.Add(new ModuleInfo("melee"));
						}

						cf.modules[moduleNumber].content.Add (LineToField (currentline));
					}
					
					else if (identifierCurrent == "module_ranged")
					{
						if (cf.modules.Count <= moduleNumber)
						{
							cf.modules.Add(new ModuleInfo("ranged"));
						}
						
						cf.modules[moduleNumber].content.Add (LineToField (currentline));
					}
					
					else if (identifierCurrent.Contains("module"))
					{
						if (cf.modules.Count <= moduleNumber)
						{
							cf.modules.Add(new ModuleInfo("unknown"));
						}
						
						cf.modules[moduleNumber].content.Add (LineToField (currentline));
					}
				}
			}
		}

		return cf;
	}

	private ConfigField LineToField (string line)
	{
		char[] delim = new char[] {'='};
		string[] parts = line.Split(delim);

		ConfigField field = new ConfigField (parts[0].Trim(), parts[1].Trim());
		return field;
	}

	private ConfigField CreateField (string key)
	{
		ConfigField field = new ConfigField (key, "");
		return ParseField (field);
	}

	private ConfigField CreateField (string key, string value)
	{
		ConfigField field = new ConfigField (key, value);
		return ParseField (field);
	}

	private ConfigField ParseField (ConfigField field)
	{
		switch (field.key)
		{
		case "usageVerb":
			field.description.Add ("\t//The verb that should be put in front of the name when a character is using this card.");
			field.description.Add ("\t//For example: 'character name' using 'a weapon name'.");
			field.description.Add ("\t//For example: Chuck Norris 'driving' the Popemobile.");
			field.description.Add ("\t//Obsolete on character cards.");
			break;

		case "type":
			field.description.Add ("\t//Determines as what kind of card the config will be loaded.");
			field.description.Add ("\t//Available types: character, weapon, armour, vehicle.");
			break;

		case "strength":
			field.description.Add ("\t//Determines the outcome of battles involving blunt damage.");
			field.description.Add ("\t//This value is only effective on character cards.");
			field.description.Add ("\t//Available values: low, high, extreme.");
			break;

		case "deployment.submerged":
			field.description.Add ("\t//On a character or vehicle this determines where a character or vehicle can be deployed.");
			field.description.Add ("\t//On armour this adds to locations where a character can be deployed.");
			field.description.Add ("\t//These values are obsolete on weapon cards.");
			break;

		case "prioritiseRangedAttack":
			field.description.Add ("\t//Determines whether the battle resolving will favour using the ranged weapon over the melee weapon.");
			field.description.Add ("\t//Set this to true if the weapon on this card is supposed to be primarily ranged (rocket launchers can be used to smack people),");
			field.description.Add ("\t//and to false if it is supposed to be primarily melee (some melee weapons can be thrown).");
			field.description.Add ("\t//This value is obsolete when there are no weapons present on the card.");
			break;

		case "enabled":
			field.description.Add ("\t//If a certain card should not have a module, simply remove the module.");
			field.description.Add ("\t//Alternatively, set this value to false.");
			break;

		case "fixedStrength":
			field.description.Add ("\t//Determines whether a weapon copies the strength from the character that wields it or not." );
			break;

		case "strengthModifier":
			field.description.Add ("\t//If the strength is not fixed, use this to modify it.");
			field.description.Add ("\t//IMPORTANT: Any character that has its fists or feet as a melee weapon should have a modifier of -1.");
			field.description.Add ("\t//If the strength is fixed, use this to set a value for it.");
			field.description.Add ("\t//Available values: 0 for low, 1 for high, 2 for extreme.");
			break;

		case "projectileSpeed":
			field.description.Add ("\t//Determines the speed of the ranged projectiles.");
			field.description.Add ("\t//Low speed projectiles can be shot down by the defender.");
			field.description.Add ("\t//Available values: low, high, beam, teleport.");
			break;

		case "projectileAmount":
			field.description.Add ("\t//Determines how many ranged projectiles are shot every volley.");
			break;

		case "targetable.submerged":
			field.description.Add ("\t//Determines what kind of areas a ranged weapon can reach. Useful to limit lock-on missile launchers.");
			field.description.Add ("\t//IMPORTANT: Think about whether this ranged weapon can aim at targets underwater, and about whether the projectiles can reach them.");
			break;

		case "enableDirectDamage":
			field.description.Add ("\t//Use this to enable or disable the various AOE ranges of the weapon.");
			field.description.Add ("\t//DirectDamage indicates damage that is done when the weapon hits the target.");
			field.description.Add ("\t//SmallblastDamage indicates damage that is done in a small to large AOE around the impact point. (Radius from grenade to ICBM.)");
			field.description.Add ("\t//LargeblastDamage indicates damage that is done in a pretty massive AOE around the impact point. Use sparingly. (Radius like a nuke.)");
			break;

		case "[0]":
			field.description.Add ("\t//On a character or vehicle this determines what kind of damage will not cause a defeat.");
			field.description.Add ("\t//On armour this adds to the character's immunities.");
			field.description.Add ("\t//These values are obsolete on weapon cards.");
			break;

		case "[1]":
			field.description.Add ("\t//Determines the kinds of damages dealt in their respective ranges.");
			field.description.Add ("\t//Any range that is disabled can be removed.");
			field.description.Add ("\t//Any damage not dealt can also be removed.");
			break;
			
		case "[2]":
			field.description.Add ("\t//Determines what kind of damage the projectile is immune to when shot by the defender.");
			field.description.Add ("\t//Obsolete when the speed isn't low.");
			break;
		}

		return field;
	}

	private void ReWriteConfigFile (ConfigFile config, string path)
	{
		string type = LoadString(config.main.content, "type");
		bool added0 = false;

		for (int i = 0; i < config.main.content.Count; i++)
		{
			ConfigField field = config.main.content[i];

			if (type == "character" && field.key == "usageVerb")
			{
				config.main.content.RemoveAt (i);
				i--;
			}
			
			else if (type != "character" && field.key == "strength")
			{
				config.main.content.RemoveAt (i);
				i--;
			}
			
			else if (type == "weapon" && (field.key.Contains ("deployment.") || field.key.Contains ("immunity.")))
			{
				config.main.content.RemoveAt (i);
				i--;
			}

			else
			{
				if (!added0 && field.key.Contains ("immunity."))
				{
					config.main.content.Insert (i, CreateField ("[0]"));
					added0 = true;
					i++;
				}

				config.main.content[i] = ParseField (field);
			}
		}

		foreach (ModuleInfo module in config.modules)
		{
			bool added1 = false;
			bool added2 = false;

			for (int i = 0; i < module.content.Count; i++)
			{
				ConfigField field = module.content[i];

				if (field.key == "fixedStrength" && (!LoadBool(module.content, "directDamage.blunt") && !LoadBool(module.content, "smallDamage.blunt") && !LoadBool(module.content, "largeDamage.blunt")))
				{
					module.content.RemoveAt (i);
					i--;
				}
				else if (field.key == "strengthModifier" && (!LoadBool(module.content, "directDamage.blunt") && !LoadBool(module.content, "smallDamage.blunt") && !LoadBool(module.content, "largeDamage.blunt")))
				{
					module.content.RemoveAt (i);
					i--;
				}
				
				else if (field.key.Contains ("immunity.") && LoadString(module.content, "projectileSpeed") != "low")
				{
					module.content.RemoveAt (i);
					i--;
				}

				else if (field.key.Contains ("directDamage.") && !ToBool(field.value))
				{
					module.content.RemoveAt (i);
					i--;
				}

				else if (field.key.Contains ("smallDamage.") && !ToBool(field.value))
				{
					module.content.RemoveAt (i);
					i--;
				}

				else if (field.key.Contains ("largeDamage.") && !ToBool(field.value))
				{
					module.content.RemoveAt (i);
					i--;
				}

				else
				{
					if (!added2 && field.key.Contains ("immunity."))
					{
						module.content.Insert (i, CreateField ("[2]"));
						added2 = true;
						i++;
					}

					if (!added1 && (field.key.Contains ("directDamage.") || field.key.Contains ("smallDamage.") || field.key.Contains ("largeDamage.")))
					{
						module.content.Insert (i, CreateField ("[spacer]"));
						module.content.Insert (i, CreateField ("[1]"));
						added1 = true;
						i += 2;
					}

					module.content[i] = ParseField (field);
				}
			}
		}

		WriteConfigToFile (config, path);
	}

	private void CreateConfig (string path, string type, string name)
	{
		ConfigFile cf = new ConfigFile ();

		// Create main body
		cf.main.content.Add (CreateField ("name", name));
		cf.main.content.Add (CreateField ("description", "template"));

		if (type != "character")
		{
			cf.main.content.Add (CreateField ("usageVerb"));
		}

		cf.main.content.Add (CreateField ("type", type));

		if (type == "character")
		{
			cf.main.content.Add (CreateField ("strength", "low"));
		}

		if (type != "weapon")
		{
			cf.main.content.Add (CreateField ("deployment.submerged", "false"));
			cf.main.content.Add (CreateField ("deployment.water", "false"));
			cf.main.content.Add (CreateField ("deployment.land", "true"));
			cf.main.content.Add (CreateField ("deployment.air", "false"));

			cf.main.content.Add (CreateField ("[0]"));
			foreach (DamageType damage in DamageTypes.damageTypes)
			{
				cf.main.content.Add (CreateField ("immunity." + damage.codeName, "false"));
			}
		}

		cf.main.content.Add (CreateField ("prioritiseRangedAttack", "false"));

		// Create melee module
		cf.modules.Add (new ModuleInfo ("melee"));

		cf.modules[0].content.Add (CreateField ("enabled", "true"));
		cf.modules[0].content.Add (CreateField ("name", "Melee Attack"));

		cf.modules[0].content.Add (CreateField ("fixedStrength", "false"));
		cf.modules[0].content.Add (CreateField ("strengthModifier", "0"));

		cf.modules[0].content.Add (CreateField ("enableDirectDamage", "true"));
		cf.modules[0].content.Add (CreateField ("enableSmallblastDamage", "false"));
		cf.modules[0].content.Add (CreateField ("enableLargeblastDamage", "false"));

		cf.modules[0].content.Add (CreateField ("[1]"));
		cf.modules[0].content.Add (CreateField ("[spacer]"));

		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[0].content.Add (CreateField ("directDamage." + damage.codeName, "false"));
		}

		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[0].content.Add (CreateField ("smallDamage." + damage.codeName, "false"));
		}

		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[0].content.Add (CreateField ("largeDamage." + damage.codeName, "false"));
		}

		// Create ranged module
		cf.modules.Add (new ModuleInfo ("ranged"));

		cf.modules[1].content.Add (CreateField ("enabled", "true"));
		cf.modules[1].content.Add (CreateField ("name", "Ranged Attack"));
		
		cf.modules[1].content.Add (CreateField ("fixedStrength", "true"));
		cf.modules[1].content.Add (CreateField ("strengthModifier", "0"));

		cf.modules[1].content.Add (CreateField ("projectileSpeed", "low"));
		cf.modules[1].content.Add (CreateField ("projectileAmount", "1"));

		cf.modules[1].content.Add (CreateField ("targetable.submerged", "false"));
		cf.modules[1].content.Add (CreateField ("targetable.water", "true"));
		cf.modules[1].content.Add (CreateField ("targetable.land", "true"));
		cf.modules[1].content.Add (CreateField ("targetable.air", "true"));

		cf.modules[1].content.Add (CreateField ("[2]"));
		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[1].content.Add (CreateField ("immunity." + damage.codeName, "false"));
		}
		
		cf.modules[1].content.Add (CreateField ("enableDirectDamage", "true"));
		cf.modules[1].content.Add (CreateField ("enableSmallblastDamage", "false"));
		cf.modules[1].content.Add (CreateField ("enableLargeblastDamage", "false"));

		cf.modules[1].content.Add (CreateField ("[1]"));
		cf.modules[1].content.Add (CreateField ("[spacer]"));
		
		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[1].content.Add (CreateField ("directDamage." + damage.codeName, "false"));
		}
		
		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[1].content.Add (CreateField ("smallDamage." + damage.codeName, "false"));
		}
		
		foreach (DamageType damage in DamageTypes.damageTypes)
		{
			cf.modules[1].content.Add (CreateField ("largeDamage." + damage.codeName, "false"));
		}

		// Write to file
		WriteConfigToFile (cf, path);
	}

	private void WriteConfigToFile (ConfigFile config, string path)
	{
		File.WriteAllText (path, "CARD" + "\n" + "{" + "\n");
		WriteModule (config.main, path, "\t");

		foreach (ModuleInfo module in config.modules)
		{
			File.AppendAllText (path, "\n");
			File.AppendAllText (path, "\tMODULE_" + module.type.ToUpper() + "\n" + "\t{" + "\n");
			
			WriteModule (module, path, "\t\t");

			File.AppendAllText (path, "\t}" + "\n");
		}

		File.AppendAllText (path, "}" + "\n");
	}

	private void WriteModule (ModuleInfo module, string path, string buffer)
	{
		bool firstLine = true;

		foreach (ConfigField field in module.content)
		{
			if (!firstLine && field.description.Count > 0)
			{
				File.AppendAllText (path, "\n");
			}

			foreach (string desc in field.description)
			{
				File.AppendAllText (path, buffer + desc + "\n");
			}
			
			if (field.key.StartsWith("[") && field.key.EndsWith("]"))
			{
				if (field.key.Contains("spacer"))
				{
					File.AppendAllText (path, "\n");
				}
			}
			else
			{
				File.AppendAllText (path, buffer + field.key + " = " + field.value + "\n");
			}

			firstLine = false;
		}
	}
}

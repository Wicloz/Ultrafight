﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum Music {None, MainMenu, Lobby, Game, Results};

public class MusicManager : MonoBehaviour
{
	public static MusicManager acces;

	public List<AudioClip> mainmenu = new List<AudioClip>();
	public List<AudioClip> lobby = new List<AudioClip>();
	public List<AudioClip> battlescenes = new List<AudioClip>();
	public List<AudioClip> results = new List<AudioClip>();

	private Music nowPlaying;
	private AudioSource musicplayer;

	void Awake ()
	{
		acces = this;
		musicplayer = this.gameObject.GetComponent<AudioSource> ();
		nowPlaying = Music.MainMenu;
	}

	void Update ()
	{
		if (!musicplayer.isPlaying)
		{
			SetMusic (nowPlaying);
		}

		musicplayer.volume = OptionsManager.acces.musicVolume;
		musicplayer.pitch = OptionsManager.acces.musicPitch;
	}

	public void StopMusic ()
	{
		musicplayer.Stop();
		nowPlaying = Music.None;
	}

	public void SetMusic (Music music)
	{
		if (music != nowPlaying || !musicplayer.isPlaying)
		{
			musicplayer.Stop();
			int random = 0;

			switch (music)
			{
			case Music.MainMenu:
				random = Random.Range(0, mainmenu.Count);
				musicplayer.clip = mainmenu[random];
				break;
			case Music.Lobby:
				random = Random.Range(0, lobby.Count);
				musicplayer.clip = lobby[random];
				break;
			case Music.Game:
				if (SwitchBox.isServer)
				{
					random = Random.Range(0, battlescenes.Count);
					GetComponent<NetworkView>().RPC ("SetGameTrack", RPCMode.AllBuffered, battlescenes[random].name);
				}
				break;
			case Music.Results:
				random = Random.Range(0, results.Count);
				musicplayer.clip = results[random];
				break;
			}

			nowPlaying = music;
			musicplayer.Play();
		}
	}

	[RPC] void SetGameTrack (string clip)
	{
		musicplayer.Stop();
		List<AudioClip> musicList = new List<AudioClip> ();

		foreach (AudioClip audio in mainmenu)
		{
			musicList.Add (audio);
		}
		foreach (AudioClip audio in lobby)
		{
			musicList.Add (audio);
		}
		foreach (AudioClip audio in battlescenes)
		{
			musicList.Add (audio);
		}
		foreach (AudioClip audio in results)
		{
			musicList.Add (audio);
		}

		foreach (AudioClip audio in musicList)
		{
			if (audio.name == clip)
			{
				musicplayer.clip = audio;
				return;
			}
		}

		nowPlaying = Music.Game;
		musicplayer.Play();
	}
}

﻿using UnityEngine;
using System.Collections;

public class LoadingScreen : MonoBehaviour
{
	public static LoadingScreen acces;

	public GameObject loadingScreen;
	public GameObject guiRoot;

	void Awake ()
	{
		acces = this;
	}

	public void StartLoading ()
	{
		MusicManager.acces.StopMusic ();

		loadingScreen.SetActive (true);
		guiRoot.SetActive (false);
	}

	public void StopLoading ()
	{
		loadingScreen.SetActive (false);
		guiRoot.SetActive (true);
	}
}

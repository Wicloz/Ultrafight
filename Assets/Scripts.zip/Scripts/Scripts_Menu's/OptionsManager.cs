﻿using UnityEngine;
using System.Collections;
using System.IO;

public enum OptionsTab {None, Video, Audio, Cards, Profile};

public class OptionsManager : MonoBehaviour
{
	public static OptionsManager acces;

	private string settingsFile;

	public InstantGuiSlider musicSlider;
	public InstantGuiSlider effectSlider;
	public InstantGuiSlider pitchSlider;

	public InstantGuiElement profileTab;

	public float musicVolume
	{
		get
		{
			return musicSlider.value;
		}
		set
		{
			musicSlider.value = value;
		}
	}
	public float effectsVolume
	{
		get
		{
			return effectSlider.value;
		}
		set
		{
			effectSlider.value = value;
		}
	}
	public float musicPitch
	{
		get
		{
			return pitchSlider.value;
		}
		set
		{
			pitchSlider.value = value;
		}
	}

	void Awake ()
	{
		acces = this;
		settingsFile = Application.dataPath + "\\..\\options.cfg";
	}

	void Start ()
	{
		LoadOptions ();
	}

	void OnDestroy ()
	{
		SaveOptions ();
	}

	void Update ()
	{
		if (GameStates.acces.majorGameState == MajorGameState.Stopped)
		{
			profileTab.disabled = false;
		}
		else
		{
			profileTab.disabled = true;
		}
	}

	public void SaveOptions ()
	{
		Settings set = new Settings ();

		set.musicVolume = this.musicVolume;
		set.effectsVolume = this.effectsVolume;
		set.musicPitch = this.musicPitch;

		SerializerHelper.SaveFileXml (set, settingsFile);
	}

	public void LoadOptions ()
	{
		if (File.Exists (settingsFile))
		{
			Settings set = SerializerHelper.LoadFileXml<Settings> (settingsFile);
			
			this.musicVolume = set.musicVolume;
			this.effectsVolume = set.effectsVolume;
			this.musicPitch = set.musicPitch;
		}

		else
		{
			SaveOptions ();
		}
	}
}

[System.Serializable]
public class Settings
{
	public float musicVolume;
	public float effectsVolume;
	public float musicPitch;

	public Settings ()
	{}
}

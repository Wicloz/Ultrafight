﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ServerGameController : MonoBehaviour
{
	public static ServerGameController acces;
	public bool gameRunning = false;

	private Dictionary<MinorGameState, bool> handledStates = new Dictionary<MinorGameState, bool> ();

	private bool serverLogic
	{
		get
		{
			if (SwitchBox.isServerOn && gameRunning && SwitchBox.isServer)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}

	public List<FightData> roundFightData = new List<FightData>();
	private bool resolvingDone = false;

	void Awake ()
	{
		acces = this;
	}

	public void Start ()
	{
		SetStates ();
	}

	public void Reset ()
	{
		gameRunning = false;

		roundFightData = new List<FightData>();
		SetStates ();
	}

	public void StartGame ()
	{
		if (SwitchBox.isServerOn)
		{
			gameRunning = true;
			NextRound();
		}
	}

	private void EndGame ()
	{
		gameRunning = false;
	}

	private void SetStates ()
	{
		handledStates = new Dictionary<MinorGameState, bool> ();

		handledStates.Add (MinorGameState.CardSelection, false);
		handledStates.Add (MinorGameState.Battle, false);
		handledStates.Add (MinorGameState.Results, false);
	}

	void Update ()
	{
		if (serverLogic)
		{
			switch (GameStates.acces.minorGameState)
			{
			case MinorGameState.CardSelection:

				bool allPlayersPicked = true;
				foreach (UserInfo user in UserManager.acces.userList)
				{
					if (user.isOnline && user.isActive && !user.states.cardSelectionDone)
					{
						allPlayersPicked = false;
					}
				}

				if (allPlayersPicked)
				{
					SendBattlePrepStart ();
				}

				break;
			case MinorGameState.Battle:



				break;
			case MinorGameState.Results:



				break;
			case MinorGameState.Loading:

				bool allCardSelectionPrepDone = true;
				foreach (UserInfo user in UserManager.acces.userList)
				{
					if (!user.states.cardSelectionPrepDone)
					{
						allCardSelectionPrepDone = false;
					}
				}

				if (allCardSelectionPrepDone && !handledStates[MinorGameState.CardSelection])
				{
					SendCardSelectionStart ();
				}

				if (resolvingDone && !handledStates[MinorGameState.Battle])
				{
					resolvingDone = false;
					SendBattleStart ();
				}
				
				break;
			}
		}
	}

	// State change announcements
	private void NextRound ()
	{
		UserManager.acces.ResetPlayerRoundInfo ();
		SendCardSelectionPrepStart ();
	}

	private void SendCardSelectionPrepStart ()
	{
		GameStates.acces.minorGameState = MinorGameState.Loading;
		GetComponent<NetworkView>().RPC("CardSelectionPrepStart", RPCMode.All);
	}

	[RPC] public void RecieveCardSelectionPrepDone (string username)
	{
		foreach (UserInfo user in UserManager.acces.userList)
		{
			if (user.username == username)
			{
				user.states.cardSelectionPrepDone = true;
			}
		}
	}

	private void SendCardSelectionStart ()
	{
		handledStates [MinorGameState.CardSelection] = true;
		GameStates.acces.minorGameState = MinorGameState.CardSelection;
		GetComponent<NetworkView>().RPC("CardSelectionStart", RPCMode.All, GameLobbyManager.acces.gameSettings.picksAmount);

		if (GameLobbyManager.acces.gameSettings.cardmode != CardMode.ClientOnly)
		{
			SendHostCards (GameLobbyManager.acces.gameSettings.picksAmount);
		}
	}
	
	private void SendBattlePrepStart ()
	{
		GameStates.acces.minorGameState = MinorGameState.Loading;
		GetComponent<NetworkView>().RPC("BattlePrepStart", RPCMode.All);
		StartCoroutine ("ResolveBattles");
	}

	private void SendBattleStart ()
	{
		handledStates [MinorGameState.Battle] = true;
		GameStates.acces.minorGameState = MinorGameState.Battle;
		GetComponent<NetworkView>().RPC("BattleStart", RPCMode.All);
	}

	private void SendResultsStart ()
	{
		handledStates [MinorGameState.Results] = true;
		GameStates.acces.minorGameState = MinorGameState.Results;
		GetComponent<NetworkView>().RPC("ResultsStart", RPCMode.All);
	}

	// Card synchronising
	[RPC] public void RecieveCard (string cardString, int list)
	{
		CardContent card = SerializerHelper.DeserializeFromString<CardContent> (cardString);

		switch (list)
		{
		case 0:
			ConfigManager.acces.AddClientCharacterCard (card);
			break;
		case 1:
			ConfigManager.acces.AddClientEquipmentCard (card);
			break;
		}
	}

	// Card selection
	private void SendHostCards (int amount)
	{
		foreach (UserInfo user in UserManager.acces.userList)
		{
			foreach (CardContent card in ConfigManager.acces.GetCharacterCards (amount))
			{
				string cardString = SerializerHelper.SerializeToString (card);
				GetComponent<NetworkView>().RPC("AddCarouselCard", RPCMode.All, user.username, cardString, 1);
			}
			
			foreach (CardContent card in ConfigManager.acces.GetEquipmentCards (amount))
			{
				string cardString = SerializerHelper.SerializeToString (card);
				GetComponent<NetworkView>().RPC("AddCarouselCard", RPCMode.All, user.username, cardString, 2);
			}
		}
	}
	
	[RPC] public void RecieveCardSelection (string username, string characterString_1, string characterString_2, string equipmentString_1, string equipmentString_2, string equipmentString_3)
	{
		string characterString = characterString_1 + characterString_2;
		string equipmentString = equipmentString_1 + equipmentString_2 + equipmentString_3;

		CardContent character = SerializerHelper.DeserializeFromString<CardContent> (characterString);
		List<CardContent> equipment = SerializerHelper.DeserializeFromString<List<CardContent>> (equipmentString);
		
		foreach (UserInfo user in UserManager.acces.userList)
		{
			if (user.username == username)
			{
				user.character = character;
				user.equipment = equipment;
				user.CalculateStats ();
				user.states.cardSelectionDone = true;
			}
		}
	}

	private void SendCard (string username, CardContent card, int carousel)
	{
		string cardString = SerializerHelper.SerializeToString (card);
		GetComponent<NetworkView>().RPC("AddCarouselCard", RPCMode.All, username, cardString, carousel);
	}

	// Battle resolver
	private IEnumerator ResolveBattles ()
	{
		foreach (UserInfo attacker in UserManager.acces.userList)
		{
			foreach (UserInfo defender in UserManager.acces.userList)
			{
				if (attacker.username != defender.username)
				{
					FightData vehicleData = new FightData (attacker, defender);
					FightData armourData = new FightData (attacker, defender);
					FightData weaponData = new FightData (attacker, defender);

					foreach (CardContent equipment in attacker.equipment)
					{
						if (equipment.type == (int)CardType.Vehicle)
						{
							vehicleData = PerformAttack (equipment, attacker, defender);

							if (vehicleData.win)
							{
								break;
							}
						}
					}

					foreach (CardContent equipment in attacker.equipment)
					{
						if (equipment.type == (int)CardType.Armour)
						{
							armourData = PerformAttack (equipment, attacker, defender);
							
							if (armourData.win)
							{
								break;
							}
						}
					}

					foreach (CardContent equipment in attacker.equipment)
					{
						if (equipment.type == (int)CardType.Weapon)
						{
							weaponData = PerformAttack (equipment, attacker, defender);
							
							if (weaponData.win)
							{
								break;
							}
						}
					}

					// Decide which outcome
					if (vehicleData.win)
					{
						roundFightData.Add (vehicleData);
						vehicleData.AssingPoints ();
					}
					else if (armourData.win)
					{
						roundFightData.Add (armourData);
						armourData.AssingPoints ();
					}
					else if (weaponData.win)
					{
						roundFightData.Add (weaponData);
						weaponData.AssingPoints ();
					}

					else
					{
						if (vehicleData.weaponName != "No Weapon!")
						{
							roundFightData.Add (vehicleData);
						}
						else if (armourData.weaponName != "No Weapon!")
						{
							roundFightData.Add (armourData);
						}
						else if (weaponData.weaponName != "No Weapon!")
						{
							roundFightData.Add (weaponData);
						}

						else
						{
							FightData data = new FightData (attacker, defender);
							roundFightData.Add (data);
						}
					}
				}
			}
			yield return null;
		}
		resolvingDone = true;
	}

	private FightData PerformAttack (CardContent equipment, UserInfo attacker, UserInfo defender)
	{
		FightData data = new FightData (attacker, defender, equipment);
		FightData meleeData = new FightData (attacker, defender, equipment);
		FightData rangedData = new FightData (attacker, defender, equipment);

		rangedData.ResolveHitSucces ();
		meleeData.ResolveHitSucces ();

		// Ranged Attack
		if (equipment.ranged.rangedEnabled && equipment.ranged.targetable.Contains((int)defender.deployment))
		{
			SectionRanged weapon = equipment.ranged;
			rangedData.weaponName = weapon.name;

			if (weapon.damageDirectEnabled)
			{
				foreach (string damagetype in weapon.damageTypesDirect)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;
					
					if (rangedData.directSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							rangedData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}
					
					else
					{
						resolve.reaction = "Evaded";
					}
					
					rangedData.resolveDirect.Add(resolve);
				}
			}
			
			if (weapon.damageSmallEnabled)
			{
				foreach (string damagetype in weapon.damageTypesSmall)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;
					
					if (rangedData.smallSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							rangedData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}
					
					else
					{
						resolve.reaction = "Evaded";
					}
					
					rangedData.resolveSmall.Add(resolve);
				}
			}
			
			if (weapon.damageLargeEnabled)
			{
				foreach (string damagetype in weapon.damageTypesLarge)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;
					
					if (rangedData.largeSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							rangedData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}
					
					else
					{
						resolve.reaction = "Evaded";
					}
					
					rangedData.resolveLarge.Add(resolve);
				}
			}
		}

		// Melee Attack
		if (equipment.melee.meleeEnabled && attacker.deployment == defender.deployment)
		{
			SectionMelee weapon = equipment.melee;
			meleeData.weaponName = weapon.name;

			if (weapon.damageDirectEnabled)
			{
				foreach (string damagetype in weapon.damageTypesDirect)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;

					if (rangedData.directSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							meleeData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}

					else
					{
						resolve.reaction = "Evaded";
					}

					meleeData.resolveDirect.Add(resolve);
				}
			}

			if (weapon.damageSmallEnabled)
			{
				foreach (string damagetype in weapon.damageTypesSmall)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;
					
					if (rangedData.smallSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							meleeData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}
					
					else
					{
						resolve.reaction = "Evaded";
					}
					
					meleeData.resolveSmall.Add(resolve);
				}
			}

			if (weapon.damageLargeEnabled)
			{
				foreach (string damagetype in weapon.damageTypesLarge)
				{
					ResolveData resolve = new ResolveData();
					resolve.damageType = damagetype;
					
					if (rangedData.largeSucces)
					{
						if (!defender.immunities.Contains(damagetype))
						{
							resolve.reaction = "Hit!";
							meleeData.win = true;
						}
						else
						{
							resolve.reaction = "Immune";
						}
					}
					
					else
					{
						resolve.reaction = "Evaded";
					}
					
					meleeData.resolveLarge.Add(resolve);
				}
			}
		}

		// No Weapons
		if (!equipment.melee.meleeEnabled && !equipment.ranged.rangedEnabled)
		{
			data.weaponName = "No Weapon!";
		}

		else if (!equipment.ranged.targetable.Contains((int)defender.deployment) && attacker.deployment != defender.deployment)
		{
			data.weaponName = "No Hit!";
		}

		// Final Check
		else
		{
			if (equipment.prioritiseRanged && rangedData.win)
			{
				data = rangedData;
			}

			else if (!equipment.prioritiseRanged && meleeData.win)
			{
				data = meleeData;
			}

			else if (equipment.prioritiseRanged)
			{
				data = rangedData;
			}

			else if (!equipment.prioritiseRanged)
			{
				data = meleeData;
			}

			else
			{
				data.weaponName = "No Weapon!";
			}
		}

		return data;
	}
}


[System.Serializable]
public class FightData
{
	public string attackerName;
	public string defenderName;

	public string weaponName;

	public List<ResolveData> resolveDirect = new List<ResolveData>();
	public List<ResolveData> resolveSmall = new List<ResolveData>();
	public List<ResolveData> resolveLarge = new List<ResolveData>();

	public bool win = false;

	// Iput data
	public bool directSucces = true;
	public bool smallSucces = true;
	public bool largeSucces = true;

	public CardContent attackEquipment;
	public UserInfo defender;
	public UserInfo attacker;

	// Functions
	public FightData ()
	{}

	public FightData (UserInfo attacker, UserInfo defender, CardContent equipment)
	{
		this.attackEquipment = equipment;
		this.defender = defender;
		this.attacker = attacker;
		this.defenderName = defender.username;
		this.attackerName = attacker.username;
	}

	public FightData (UserInfo attacker, UserInfo defender)
	{
		this.weaponName = "No Weapon!";
		this.defender = defender;
		this.attacker = attacker;
		this.defenderName = defender.username;
		this.attackerName = attacker.username;
	}

	public void ResolveHitSucces ()
	{
		if (attackEquipment.ranged.rangedEnabled)
		{
			foreach (CardContent defensive in defender.equipment)
			{
				if (attackEquipment.ranged.speed == (int)ProjectileSpeed.Low && defensive.type == (int)CardType.Weapon && defensive.ranged.rangedEnabled && defensive.ranged.targetable.Contains((int)Deployment.Air))
				{
					if (defensive.ranged.damageDirectEnabled)
					{
						foreach (string damagetype in defensive.ranged.damageTypesDirect)
						{
							if (!defensive.ranged.projectileImmunities.Contains(damagetype))
							{
								directSucces = false;
								smallSucces = false;
							}
						}
					}
					
					if (defensive.ranged.damageSmallEnabled)
					{
						foreach (string damagetype in defensive.ranged.damageTypesSmall)
						{
							if (!defensive.ranged.projectileImmunities.Contains(damagetype))
							{
								directSucces = false;
								smallSucces = false;
							}
						}
					}
					
					if (defensive.ranged.damageLargeEnabled)
					{
						foreach (string damagetype in defensive.ranged.damageTypesLarge)
						{
							if (!defensive.ranged.projectileImmunities.Contains(damagetype))
							{
								directSucces = false;
								smallSucces = false;
							}
						}
					}
				}
			}
		}
	}

	public void AssingPoints ()
	{
		if (win)
		{
			attacker.kills ++;
			defender.deaths --;
		}
	}
}

[System.Serializable]
public class ResolveData
{
	public string damageType;
	public string reaction;

	public ResolveData ()
	{}

	public ResolveData (string damageType, string reaction)
	{
		this.damageType = damageType;
		this.reaction = reaction;
	}
}

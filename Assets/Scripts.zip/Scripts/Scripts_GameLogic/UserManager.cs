﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class States
{
	public bool cardSelectionPrepDone = false;
	public bool cardSelectionDone = false;

	public void Reset ()
	{
		cardSelectionPrepDone = false;
		cardSelectionDone = false;
	}

	public States ()
	{}
}

[System.Serializable]
public class UserInfo
{
	public string username;

	public bool isOnline = true;
	public bool isActive = true;
	public bool isWelcomed = false;

	public bool checkPing = false;
	public bool isHost = false;

	public States states = new States ();

	public int kills = 0;
	public int deaths = 0;

	public int roundsWon = 0;
	public int swagPoints = 0;

	public CardContent character;
	public List<CardContent> equipment;
	
	public Deployment deployment;
	public List<string> immunities = new List<string>();

	public UserInfo ()
	{
		username = "ERROR";
	}
	
	public UserInfo (string Username)
	{
		username = Username;
	}

	public void CalculateStats ()
	{
		foreach (string immunity in character.immunities)
		{
			if (!immunities.Contains (immunity))
			{
				immunities.Add (immunity);
			}
		}
		
		foreach (CardContent item in equipment)
		{
			if (item.type == (int)CardType.Armour)
			{
				foreach (string immunity in item.immunities)
				{
					if (!immunities.Contains (immunity))
					{
						immunities.Add (immunity);
					}
				}
			}
		}
	}
}

public class UserManager : MonoBehaviour
{
	public static UserManager acces;
	public List<UserInfo> userList = new List<UserInfo>();
	public List<bool> pingList = new List<bool>();

	public UserInfo thisUser;

	public List<InstantGuiPopup> userInfoFields = new List<InstantGuiPopup>();

	void Awake ()
	{
		acces = this;
	}

	void Start ()
	{
		StartCoroutine (CheckForTimeouts ());
	}

	void OnDestroy ()
	{
		if (SwitchBox.isServer && SwitchBox.isServerOn)
		{
			GetComponent<NetworkView>().RPC("KickClient", RPCMode.Others, "", true, "Server Closed");
		}
	}

	public void Reset ()
	{
		userList = new List<UserInfo>();
		pingList = new List<bool>();
	}

	void Update ()
	{
		for (int i = 0; i < userInfoFields.Count; i++)
		{
			if (userInfoFields[i].list.labels[userInfoFields[i].list.selected] == "Kick Player" && SwitchBox.isServer)
			{
				KickUser (userInfoFields[i].list.labels[0]);
			}

			userInfoFields[i].list.selected = 0;
			userInfoFields[i].gameObject.SetActive (false);
		}

		int index = 1;
		foreach (UserInfo user in userList)
		{
			if (user.username == ProfileManager.acces.profile.username)
			{
				thisUser = user;
			}

			if (user.isHost)
			{
				SetUserInfofield (userInfoFields[0], user);
			}

			else
			{
				SetUserInfofield (userInfoFields[index], user);
				index ++;
			}
		}
	}

	private void SetUserInfofield (InstantGuiPopup field, UserInfo user)
	{
		field.gameObject.SetActive (true);
		field.check = user.isOnline;

		int index = 0;
		field.list.labels[index] = user.username;
		index ++;

		if (user.isActive)
		{
			field.list.labels[index] = "Kills: " + user.kills;
			index ++;
			field.list.labels[index] = "Deaths: " + user.deaths;
			index ++;
			
			if (GameLobbyManager.acces.gameSettings.gamemode != GameMode.TotalScore)
			{
				field.list.labels[index] = "Wins: " + user.roundsWon;
				index ++;
			}
			
			field.list.labels[index] = "Swagpoints: " + user.swagPoints;
			index ++;
		}
		else
		{
			field.list.labels[index] = "Spectator";
			index ++;
		}
		
		if (SwitchBox.isServer && user.isOnline && user.username != ProfileManager.acces.profile.username)
		{
			field.list.labels[index] = "Kick Player";
		}
		else
		{
			field.list.labels[index] = "";
		}
	}

	// Manipulate user data
	public void ResetPlayerGameInfo ()
	{
		for (int i = 0; i < userList.Count; i++)
		{
			UserInfo user = userList[i];

			user.kills = 0;
			user.deaths = 0;
			
			user.roundsWon = 0;
			user.swagPoints = 0;

			SendUser (user.username);
		}
	}
	
	public void ResetPlayerRoundInfo ()
	{
		for (int i = 0; i < userList.Count; i++)
		{
			UserInfo user = userList[i];

			if (GameLobbyManager.acces.gameSettings.gamemode != GameMode.TotalScore)
			{
				user.kills = 0;
				user.deaths = 0;
			}

			user.states.Reset();

			user.character = null;
			user.immunities = new List<string>();
			user.equipment = null;

			SendUser (user.username);
		}
	}

	// Client synchronisation
	private void SendUser (string username)
	{
		foreach (UserInfo user in userList)
		{
			if (user.username == username)
			{
				List<string> stringSections = SerializerHelper.SerializeToString (user, 4);
				GetComponent<NetworkView>().RPC("RecieveUser", RPCMode.Others, stringSections[0], stringSections[1], stringSections[2], stringSections[3]);
				break;
			}
		}
	}
	
	[RPC] public void RecieveUser (string string_1, string string_2, string string_3, string string_4)
	{
		if (!SwitchBox.isServer)
		{
			string userString = string_1 + string_2 + string_3 + string_4;

			UserInfo user = SerializerHelper.DeserializeFromString<UserInfo> (userString);
			bool userExists = false;

			for (int i = 0; i < userList.Count; i++)
			{
				if (userList[i].username == user.username)
				{
					userList[i] = user;
					userExists = true;
					break;
				}
			}
			
			if (!userExists)
			{
				userList.Add (user);
			}
		}
	}

	// Manage users
	public void KickUser (string username)
	{
		GetComponent<NetworkView>().RPC("KickClient", RPCMode.Others, username, false, "Kicked by Host");
		DisconnectUser (username, " was kicked.");
	}

	[RPC] public void AddUser (string username)
	{
		bool userExists = false;

		for (int i = 0; i < userList.Count; i++)
		{
			if (userList[i].username == username)
			{
				userExists = true;
				userList[i].isOnline = true;

				break;
			}
		}

		if (!userExists)
		{
			UserInfo info = new UserInfo (username);

			if (username == ProfileManager.acces.profile.username)
			{
				info.isHost = true;
			}

			userList.Add (info);
		}

		foreach (UserInfo user in userList)
		{
			if (!user.isWelcomed)
			{
				if (GameStates.acces.majorGameState == MajorGameState.Running)
				{
					GameLobbyManager.acces.SendGameStarted ();
					user.isActive = false;
				}
				
				user.isWelcomed = true;
			}
			
			SendUser (user.username);
		}
		
		HostGameManager.acces.RegisterHost ();
	}

	[RPC] public void RemoveUser (string username)
	{
		for (int i = 0; i < userList.Count; i++)
		{
			if (userList[i].username == username)
			{
				userList.RemoveAt(i);
				break;
			}
		}
	}

	public void RemoveOfflineUsers ()
	{
		for (int i = 0; i < userList.Count; i++)
		{
			if (!userList[i].isOnline)
			{
				userList.RemoveAt(i);
				i--;
			}
		}
	}

	public void SetUsersActive ()
	{
		foreach (UserInfo user in userList)
		{
			user.isActive = true;
		}
	}

	// Retrieve information
	public List<string> GetSimpleUserList ()
	{
		List<string> returnList = new List<string> ();

		for (int i = 0; i < userList.Count; i++)
		{
			if (userList[i].isOnline)
			{
				returnList.Add(userList[i].username);
			}
		}

		return returnList;
	}

	// Managing player connections
	[RPC] public void DisconnectUser (string username, string reason)
	{
		foreach (UserInfo user in userList)
		{
			if (user.username == username)
			{
				user.isOnline = false;
				user.isWelcomed = false;
				ChatManager.acces.SendServerMessage(user.username + reason);
				break;
			}
		}
	}
	
	void OnPlayerConnected ()
	{}

	void OnPlayerDisconnected ()
	{
		CheckConnection (" left the game.");
	}

	// Ping system
	private IEnumerator CheckForTimeouts ()
	{
		while (true)
		{
			yield return new WaitForSeconds (10);

			if (SwitchBox.isServerOn && SwitchBox.isServer)
			{
				CheckConnection (" timed out.");
			}

			yield return new WaitForSeconds (10);
		}
	}

	public void CheckConnection (string message)
	{
		pingList = new List<bool>();
		
		foreach (UserInfo user in userList)
		{
			pingList.Add(false);
			
			if (user.username != ProfileManager.acces.profile.username && user.isOnline)
			{
				user.checkPing = true;
				GetComponent<NetworkView>().RPC("Marco", RPCMode.All, user.username);
			}
			else
			{
				user.checkPing = false;
			}
		}

		StopCoroutine ("DelayedConnectionCheck");
		StartCoroutine ("DelayedConnectionCheck", message);
	}

	[RPC] public void Polo (string username)
	{
		for (int i = 0; i < userList.Count; i++)
		{
			if (userList[i].username == username)
			{
				pingList[i] = true;
				break;
			}
		}
	}

	private IEnumerator DelayedConnectionCheck (string message)
	{
		bool done = false;
		float starttime = Time.time;

		while (!done)
		{
			if (Time.time - starttime > 1)
			{
				for (int i = 0; i < userList.Count; i++)
				{
					if (userList[i].checkPing && !pingList[i])
					{
						DisconnectUser (userList[i].username, message);
					}

					SendUser (userList[i].username);
				}
				
				HostGameManager.acces.RegisterHost ();
				done = true;
			}

			yield return null;
		}
	}
}

﻿using UnityEngine;
using System.Collections;

public class CardBehaviour : MonoBehaviour
{
	public bool isClicked = false;
	public bool isSelected = false;

	private Material original;
	public Material selected;

	public bool mouseDown = false;

	public TypogenicText textMesh;
	public CardContent card;

	void Awake ()
	{
		original = this.gameObject.GetComponent<Renderer>().material;
	}

	void OnMouseDown ()
	{
		isClicked = true;
		mouseDown = true;
	}

	void OnMouseUp ()
	{
		mouseDown = false;
	}

	void Update ()
	{
		if (isSelected)
		{
			this.gameObject.GetComponent<Renderer>().material = selected;
		}
		else
		{
			this.gameObject.GetComponent<Renderer>().material = original;
		}
	}

	public void InitialiseCard (CardContent card)
	{
		this.card = card;
		textMesh.Text = this.card.name;

		for (int i = 0; i < 400; i++)
		{
			textMesh.Text = textMesh.Text + " ";
		}
		textMesh.Text = textMesh.Text + ".";
	}
}
